$('#btn_lawyer_save').on('click', function(){
    var token = $('#token').val();
    var id = 0;
    var data = $('#btn_lawyer_save').data('id');
    if(typeof data == 'undefined') {
        var lawyer = { 'id':0, 'identification': $('#identification').val(), 'registration_number': $('#registration_number').val(), 'first_name': $('#first_name').val(), 'last_name': $('#last_name').val(), 'email': $('#email').val(), 'telephone': $('#telephone').val(), 'mobile': $('#mobile').val(), 'address': $('#address').val()};
        $.ajax({
            url : '/lawyer_create',
            headers:{'X-CSRF-TOKEN' : token},
            type:'POST',
            dataType: 'json',
            data:lawyer,
            success:function(r)
            {
                debugger;
                if(r.mensaje == "ok") {
                    ClearLawyerForm();
                    $('#myModal').modal('toggle');
                    window.location.reload();
                    var n = noty({text: 'Abogado registrado Correctamente!', type: 'success'});
                }
                else{
                    var n = noty({text: r.mensaje, type: 'error'});
                }
            },
            error:function(r)
            {
                debugger;
                var e = r.responseJSON ;
                if(typeof e != 'undefined')
                {
                    var msg = "";
                    $.each( e, function(i, n){
                        msg = msg += n+'<br/>';
                    });
                    var n = noty({  text: msg, type: 'warning'});
                }
                else {
                    var n = noty({text: 'Hay errores en el envi&#243; de datos!', type: 'error'});
                }
            }
        });
    }
    else
    {
        var lawyer = { 'id':data, 'identification': $('#identification').val(), 'registration_number': $('#registration_number').val(), 'first_name': $('#first_name').val(), 'last_name': $('#last_name').val(), 'email': $('#email').val(), 'telephone': $('#telephone').val(), 'mobile': $('#mobile').val(), 'address': $('#address').val()};
        $.ajax({
            url : '/lawyer_edit/'+data,
            headers:{'X-CSRF-TOKEN' : token},
            type:'POST',
            dataType: 'json',
            data:lawyer,
            success:function(r)
            {
                if(r.mensaje == "ok") {
                    ClearLawyerForm();
                    $('#myModal').modal('toggle');
                    window.location.reload();
                    var n = noty({text: 'Abogado actualizado Correctamente!', type: 'success'});
                }
                else{
                    var n = noty({text: r.mensaje, type: 'error'});
                }
            },
            error:function(r)
            {
                var e = r.responseJSON ;
                if(typeof e != 'undefined')
                {
                    var msg = "";
                    $.each( e, function(i, n){
                        msg = msg += n+'<br/>';
                    });
                    var n = noty({  text: msg, type: 'warning'});
                }
                else {
                    var n = noty({text: 'Hay errores en el envi&#243; de datos!', type: 'error'});
                }
            }
        });
    }

});

$('#lawyer_new').click(function(){
    $('#btn_lawyer_save').removeAttr('data-id');
    ClearLawyerForm();
});

function ClearLawyerForm() {
    $('#identification').val('');
    $('#registration_number').val('');
    $('#first_name').val('');
    $('#last_name').val('');
    $('#email').val('');
    $('#telephone').val('');
    $('#mobile').val('');
    $('#address').val('');
}

function SetEditLawyer(id){
    $('#btn_lawyer_save').attr('data-id',id);
    var token = $('#token').val();
    $.ajax({
        url : '/lawyer_edit/'+id,
        headers:{'X-CSRF-TOKEN' : token},
        type:'GET',
        dataType: 'json',
        success:function(r)
        {
            $('#identification').val(r.identification);
            $('#registration_number').val(r.registration_number);
            $('#first_name').val(r.first_name);
            $('#last_name').val(r.last_name);
            $('#email').val(r.email);
            $('#telephone').val(r.telephone);
            $('#mobile').val(r.mobile);
            $('#address').val(r.address);
        },
        error:function(r)
        {
            var n = noty({text: 'Errores en la obtenci&#243n de datos!', type: 'error'});
        }
    });
};

function ViewLawyer(id){
    $.ajax({
        url : '/lawyer_edit/'+id,
        headers:{'X-CSRF-TOKEN' : token},
        type:'GET',
        dataType: 'json',
        success:function(r)
        {
            $('#lblidentification').text(r.identification);
            $('#lblregistration_number').text(r.registration_number);
            $('#lblfirst_name').text(r.first_name);
            $('#lbllast_name').text(r.last_name);

            $('#lblgender').text(r.gender == 'M'?'Masculino':'Fememenino');
            $('#lblemail').text(r.email);
            $('#lbltelephone').text(r.telephone);
            $('#lblmobile').text(r.mobile);
            $('#lbladdress').text(r.address);
        },
        error:function(r)
        {
            var n = noty({text: 'Errores en la obtenci&#243n de datos!', type: 'error'});
        }
    });
};

function DeleteLawyer(id) {
    noty({
        text: '&#191;Est&#225; seguro de querer eliminar el registro?',
        buttons: [
            {addClass: 'btn btn-primary', text: 'Si', onClick: function($noty) {
                $noty.close();
                var token = $('#token').val();
                //***************//
                    $.ajax({
                        url : '/lawyer_delete/'+id,
                        headers:{'X-CSRF-TOKEN' : token},
                        type:'POST',
                        dataType: 'json',
                        success:function(r)
                        {
                            if(r.mensaje == "ok") {
                                window.location.reload();
                                var n = noty({text: 'Registro Eliminado Correctamente!', type: 'success'});
                            }
                        },
                        error:function(r)
                        {
                            debugger;
                            var s = r;
                            var n = noty({text: 'Errores!', type: 'error'});
                        }
                    });
                //**************//
            }
            },
            {addClass: 'btn btn-danger', text: 'Cancelar', onClick: function($noty) {
                $noty.close();
                noty({text: 'Acci&#243;n Cancelada ', type: 'information'});
            }
            }
        ]
    });

}

//*********** restore lawyer *************//
function RestoreLawyer(id) {
    $('#btn_lawyer_restore').attr('data-id',id);
}

$('#btn_lawyer_restore').on('click', function(){
    var token = $('#token').val();
    var id = $('#btn_lawyer_restore').data('id');
    var lawyer = { 'id':id, 'identification': $('#identification').val(), 'registration_number': $('#registration_number').val(), 'first_name': 'xxx', 'last_name': 'xxx', 'email': 'xx@yy.zz', 'telephone': 555555, 'mobile': 9955555555, 'address': 'xx yy zz'};

    $.ajax({
        url : '/lawyer_restore/'+id,
        headers:{'X-CSRF-TOKEN' : token},
        type:'POST',
        dataType: 'json',
        data:lawyer,
        success:function(r)
        {
            if(r.mensaje == "ok") {
                ClearLawyerForm();
                $('#myModalRestore').modal('toggle');
                window.location.reload();
                var n = noty({text: 'Abogado Restaurado Correctamente!', type: 'success'});
            }
            else{
                var n = noty({text: r.mensaje, type: 'error'});
            }
        },
        error:function(r)
        {
            var e = r.responseJSON ;
            if(typeof e != 'undefined')
            {
                var msg = "";
                $.each( e, function(i, n){
                    msg = msg += n+'<br/>';
                });
                var n = noty({  text: msg, type: 'warning'});
            }
            else {
                var n = noty({text: 'Hay errores en el envi&#243; de datos!', type: 'error'});
            }
        }
    });
});

//********** contributions *****//
function SavePay() {
    var token = $('#token').val();
    var lawyer_id = $("#lawyer_id").val();
    var year = $("#year").val();
    var month = $("#month").val();
    var amount = $("#amount").val();
    var description = $("#description").val();

    var contribution = { 'id':0, 'lawyer_id': lawyer_id, 'year': year, 'month': $('#month').val(), 'amount': $('#amount').val(), 'description': $('#description').val() };
    $.ajax({
        url : '/contribution_register',
        headers:{'X-CSRF-TOKEN' : token},
        type:'POST',
        dataType: 'json',
        data:contribution,
        success:function(r)
        {
            debugger;
            if(r.mensaje == "ok") {
                debugger;
                var n = noty({text: 'Pago registrado correctamente!', type: 'success'});
                ClearFormPay();
            }
            else{
                debugger;
                var n = noty({text: 'Error', type: 'error'});
            }
        },
        error:function(r)
        {
            debugger;
            var e = r.responseJSON ;
            if(typeof e != 'undefined')
            {
                var msg = "";
                $.each( e, function(i, n){
                    msg = msg += n+'<br/>';
                });
                var n = noty({  text: msg, type: 'warning'});
            }
            else {
                debugger
                var n = noty({text: 'Hay errores en el envi&#243; de datos!', type: 'error'});
            }
        }
    });

}

function ClearFormPay() {
   $("#lawyer_id").val('');
    $("#txtIdentification").val('');
    $('#registration_number').val('');
    $('#first_name').val('');
    $('#last_name').val('');
   //$("#year").val();
   //$("#month").val();
   $("#amount").val('');
   $("#description").val('');
}

function SeachLawyer() {
    $('#registration_number').val('');
    $('#first_name').val('');
    $('#last_name').val('');
    $('#lawyer_id').val('');

    var identification = $('#txtIdentification').val();
    if (isNaN(identification)) {
        $('#txtIdentification').val('');
        var n = noty({text: 'Ingrese solo n&#250;meros!', type: 'warning'});
        return;
    }
    $.ajax({
        url : '/lawyer_search/'+identification,
        type:'GET',
        dataType: 'json',
        success:function(r)
        {
            $('#lawyer_id').val(r.id);
            $('#registration_number').val(r.registration_number);
            $('#first_name').val(r.first_name);
            $('#last_name').val(r.last_name);
        },
        error:function(r)
        {
            var n = noty({text: 'No se encontr&#243; registro con la c&#233;dula ingresada!', type: 'information'});
        }
    });
}

$(function() {
    var now = new Date(Date.now());
    $('#year').val(now.getFullYear());
    var month = now.getMonth()+1;
    $('#month option[value='+month+']').attr('selected','selected');
});

$('#btn_year_down').on('click',function(){
    var year = parseInt($('#year').val());
    year--;
    $('#year').val(year);
});

$('#btn_year_up').on('click',function(){
    var year = parseInt($('#year').val());
    year++;
    $('#year').val(year);
});

$('#btn_year_down2').on('click',function(){
    var year = parseInt($('#year2').val());
    year--;
    $('#year2').val(year);
});

$('#btn_year_up2').on('click',function(){
    var year = parseInt($('#year2').val());
    year++;
    $('#year2').val(year);
});

$("#filters").collapse();
